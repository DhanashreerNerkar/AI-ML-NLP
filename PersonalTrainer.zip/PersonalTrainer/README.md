(on website)
CREATE OPEN-AI ACCOUNT 
1. Open-ai SECRET-KEY to connect to open-ai

(in VSCode Project)
1. CREATE .env File to save Open-ai SECRET-KEY and further use in python script
2. CREATE requirements.txt file to mention all packages to be installed
    - python-dotenv
    - openai
3. CREATE .gitignore file to bypass few files like .env
4. Terminal Commands: 
    - python -m venv myenv
    - myenv\Scripts\activate
5. CREATE Writing main.py
